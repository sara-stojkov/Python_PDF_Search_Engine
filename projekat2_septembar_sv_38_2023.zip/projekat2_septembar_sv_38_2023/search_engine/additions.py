def highlight_word_in_pdf(word):

    pass

def save_results_to_pdf():
    pass